import { Router } from "express";
import * as express from "express";
import { verifyCinetPayWebhook } from "../../middlewares/verifyWebhook";
import {
  initiatePayment,
  paymentWebhook,
  paymentCallback,
} from "./payment.controller";

const router = Router();

router.post(
  "/webhook/cinetpay",
  verifyCinetPayWebhook,
  express.raw({ type: "application/json" }),
  paymentWebhook
);

router.post("/initiate", initiatePayment);
router.get("/callback", paymentCallback);

export const paymentRoutes = router;
