import mongoose, { Document, Schema } from "mongoose";

export interface ITransaction extends Document {
  bookingId: mongoose.Types.ObjectId;
  amount: number;
  method: string;
  status: "pending" | "paid" | "failed";
  externalRef?: string;
  provider: "cinetpay";
  createdAt: Date;
  updatedAt: Date;
}

const transactionSchema = new Schema<ITransaction>(
  {
    bookingId: {
      type: Schema.Types.ObjectId,
      ref: "Booking",
      required: true,
    },
    amount: { type: Number, required: true },
    method: { type: String, required: true },

    status: {
      type: String,
      enum: ["pending", "paid", "failed"],
      default: "pending",
    },

    externalRef: { type: String },
    provider: {
      type: String,
      enum: ["cinetpay"],
      default: "cinetpay",
    },
  },
  { timestamps: true }
);

export const Transaction = mongoose.model<ITransaction>(
  "Transaction",
  transactionSchema
);

