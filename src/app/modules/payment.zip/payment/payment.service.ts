import axios from "axios";
import * as crypto from "crypto";
import { Booking } from "../booking/booking.model";
import { Transaction } from "./transaction.model";
import { BOOKING_STATUS } from "../booking/booking.interface";

const env = process.env as any;

export const initiate = async (data: any) => {
  const booking = await Booking.findById(data.bookingId);
  if (!booking || booking.status !== BOOKING_STATUS.PENDING) {
    throw new Error("Booking not found or already paid");
  }

  const transactionRef = `TXN_${Date.now()}_${Math.random()
    .toString(36)
    .substr(2, 9)}`;

  const payload = {
    apikey: env.CINATPAY_API_KEY,
    site_id: env.CINATPAY_SITE_ID,
    transaction_id: transactionRef,
    amount: booking.totalAmount,
    currency: "XOF",
    description: `Car Booking #${booking._id}`,
    channels: mapMethodToChannel(data.paymentMethod),
    metadata: {
      booking_id: booking._id.toString(),
      user_id: booking.userId.toString(),
    },
    customer_name: data.customerName,
    customer_email: data.customerEmail,
    customer_phone_number: data.customerPhone,
    customer_address: "Lomé, Togo",
    notify_url: `${env.BASE_URL}/api/payments/webhook/cinetpay`,
    return_url: `${env.BASE_URL}/payment/callback`,
  };

  try {
    const response = await axios.post(
      "https://api-checkout.cinetpay.com/v2/payment",
      payload
    );

    if (response.data.code === "201") {
      await Transaction.create({
        bookingId: booking._id,
        amount: booking.totalAmount,
        method: data.paymentMethod,
        externalRef: transactionRef,
      });

      return {
        success: true,
        paymentLink: response.data.payment_url,
        transactionRef,
        message: "Payment link generated",
      };
    }

    throw new Error(response.data.message || "Payment initiation failed");
  } catch (err: any) {
    throw new Error(err.response?.data?.message || err.message);
  }
};

export const handleWebhook = async (body: any, signature: string) => {
  const expected = crypto
    .createHmac("sha256", env.CINATPAY_SECRET_KEY)
    .update(JSON.stringify(body))
    .digest("hex");

  if (expected !== signature) {
    console.log("Invalid webhook signature");
    return false;
  }

  if (
    body.cinetpay_response?.code === "00" &&
    body.cinetpay_response?.status === "ACCEPTED"
  ) {
    const bookingId = body.metadata?.booking_id;
    const booking = await Booking.findById(bookingId);

    if (booking && booking.status === BOOKING_STATUS.PENDING) {
      booking.status = BOOKING_STATUS.PAID;
      await booking.save();

      await Transaction.updateOne(
        { externalRef: body.transaction_id },
        { status: "paid" }
      );

      console.log(`Booking ${bookingId} paid successfully`);
      return true;
    }
  }

  return false;
};

const mapMethodToChannel = (method: string): string[] => {
  const map: Record<string, string[]> = {
    creditCard: ["CARD"],
    eWallet: ["WALLET"],
    flooz: ["MOBILE_MONEY"],
    missByYaas: ["MOBILE_MONEY"],
  };

  return map[method] || ["CARD", "WALLET", "MOBILE_MONEY"];
};
