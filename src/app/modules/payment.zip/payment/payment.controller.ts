import { Request, Response } from "express";
import * as PaymentService from "./payment.service";

export const initiatePayment = async (req: Request, res: Response) => {
  try {
    const result = await PaymentService.initiate(req.body);
    res.json(result);
  } catch (error: any) {
    res.status(400).json({
      success: false,
      message: error.errors?.[0]?.message || error.message,
    });
  }
};

export const paymentWebhook = async (req: Request, res: Response) => {
  try {
    const signature = req.headers["x-cinetpay-signature"] as string;
    const success = await PaymentService.handleWebhook(req.body, signature);

    res.json({ success });
  } catch (error) {
    console.error("Webhook error:", error);
    res.status(400).json({ message: "Webhook processing failed" });
  }
};

export const paymentCallback = (req: Request, res: Response) => {
  const status = req.query.status;

  if (status === "success") {
    return res.redirect("myapp://payment-success");
  }
  res.redirect("myapp://payment-failed");
};
